# Vue Material Admin

### Introduction
Vue Material Admin Template is a [Vue](https://vuejs.org/index.html/) Based Material Design Admin Template.
And use [Vuetifyjs](https://vuetifyjs.com/) as base framework.
Vuetify is Awesome.

### Demo
[http://vma.isocked.com/#/dashboard](http://vma.isocked.com/#/dashboard) 

### Preview
![Preivew](http://vma.isocked.com//static/preview/01_preview.png)

###
### Project Structure
```bash
├── build
├── config (Webpack)
├── src
│   ├── api
│   ├── components
│   ├── mixins
│   ├── pages (or views)
│   ├── router
│   ├── util
│   ├── theme
│   │   ├── default.styl
│   └── App.vue
│   └── event.js
│   └── main.js
├── dist
├── release
├── static (or asset)
├── mock (or script to build mock data)
├── node_modules
├── test
├── README.md
├── package.json
├── index.html
└── .gitignore

### Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

### Reference

* [Vuetifyjs](https://vuetifyjs.com/)
* [Vue](https://vuejs.org/index.html/)
* [ECharts](http://echarts.baidu.com/option.html)
* [Stylus](http://stylus-lang.com/)

### Donate
If you find this project useful, you can buy author a glass of juice :tropical_drink:


[Paypal Me](https://www.paypal.me/tookit)

[Buy me a coffee](https://www.buymeacoffee.com/tookit)

<a href="https://www.buymeacoffee.com/tookit" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: auto !important;width: auto !important;" ></a>

## License

[MIT](https://github.com/tookit/vue-material-admin/blob/master/LICENSE)