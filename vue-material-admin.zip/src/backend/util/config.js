module.exports = {
  jwtSecret: "trunglatrung",
  db_host: "localhost",
  db_port: "3306",
  db_user: "root",
  db_pass: "root",
  db_datatbase: "24hcode",
  db_conn_limit: 10
};
