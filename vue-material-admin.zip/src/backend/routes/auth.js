/*
 * Filename: d:\Project\vue-material-admin\src\backend\route\loginRoute.js
 * Path: d:\Project\vue-material-admin
 * Created Date: Saturday, April 6th 2019, 4:51:40 pm
 * Author: trung
 *
 * Copyright (c) 2019 Your Company
 */

"use strict";
var express = require("express");
var router = express.Router();
var controller = require("../controllers/authCtrl");
module.exports = router;
// router.post("/login", controller.login);
